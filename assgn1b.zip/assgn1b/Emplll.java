package com.assgn1b;

public class Emplll {

    public String firstname;
    public String lastname;
    public int age;
    public double salary;

    public  Emplll(String Fn, String Ln, int A, double S) {
        this.firstname = Fn;
        this.lastname = Ln;
        this.age = A;
        this.salary = S;
    }
}
