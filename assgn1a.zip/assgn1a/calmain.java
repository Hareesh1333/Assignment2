package com.assgn1a;

import java.util.Scanner;

public class calmain  {
    public static void main(String[] args) {

        System.out.println("Operators are + , - , * , / , % , SIN - 's' , COS - 'c' , TAN - 't' , COT - 'C' .");
        Scanner sa = new Scanner(System.in);


        addition a1 = new addition();
        substraction s1 = new substraction();
        multiplication m1 = new multiplication();
        division d1 = new division();
        modulus m2 = new modulus();
        sin s2 = new sin();
        cos c1 = new cos();
        tan t1 = new tan();
        cot c2 = new cot();

        System.out.print("Enter Operator to perform an operation : ");
        char oprator = sa.next().charAt(0);
        switch (oprator){
            case'+':
                System.out.println("Addition of a + b : " + a1.add());
                 break;
            case '-':
                System.out.println("Substraction of a - b : " + s1.sub());
                break;
            case '*':
                System.out.println("Multiplication of a * b : " + m1.mul());
                break;
            case '/':
                System.out.println("Division of a / b : " + d1.div());
                break;
            case '%':
                System.out.println("Modulus of a % b : " + m2.mod());
                break;
            case 's':
                System.out.println("Sin : " + s2.sin());
                break;
            case 'c':
                System.out.println("Cos : " + c1.cos());
                break;
            case 't':
                System.out.println("Tan : " + t1.tan());
            case 'C':
                System.out.println("Cot : " + c2.Cot());


        }

    }
}
