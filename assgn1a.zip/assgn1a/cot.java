package com.assgn1a;

import java.util.Scanner;

public class cot
{
    Scanner sc = new Scanner(System.in);
    public double Cot(){
        System.out.println("Enter value of a : ");
        double a = sc.nextDouble();
        double b = Math.toRadians(Math.cos(a))/(Math.sin(a));
        return b;
    }
}
