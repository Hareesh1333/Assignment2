package com.assgn1a;

import java.util.Scanner;

public class addition {
    Scanner sc = new Scanner(System.in);
    public int add() {
        System.out.println("Enter value of a : ");
        int a = sc.nextInt();
        System.out.println("Enter value of b : ");
        int b = sc.nextInt();
        int c = a + b;
        return c;
    }

}
