package com.assgn1a;

import java.util.Scanner;

public class tan {
    Scanner sc = new Scanner(System.in);
    public double tan(){
        System.out.println("Enter value of a : ");
        double a = sc.nextDouble();
        double b = Math.toRadians(Math.tan(a));
        return b;
    }
}
