package com.assgn1a;

import java.util.Scanner;

public class cos {
    Scanner sc = new Scanner(System.in);
    public double cos(){
        System.out.println("Enter value of a : ");
        double a = sc.nextDouble();
        double b = Math.toRadians(Math.cos(a));
        return b;
    }
}
