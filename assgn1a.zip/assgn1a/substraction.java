package com.assgn1a;

import java.util.Scanner;

public class substraction {
    Scanner sp = new Scanner(System.in);
    public int sub() {
        System.out.println("Enter value of a : ");
        int a = sp.nextInt();
        System.out.println("Enter value of b : ");
        int b = sp.nextInt();
        int c = a - b;
        return c;
    }
}
